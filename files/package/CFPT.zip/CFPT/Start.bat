@echo off
setlocal EnableDelayedExpansion
title CF-PH GAME STARTER
color 0A

:: ── Dynamic path resolution ──────────────────────────────────────────────────
:: BAT is at the root (same level as "Cert Sign Tools" and "DLL" folders)
set "BASE_DIR=%~dp0"
if "%BASE_DIR:~-1%"=="\" set "BASE_DIR=%BASE_DIR:~0,-1%"

set "CERT_DIR=%BASE_DIR%\Cert Sign Tools"
set "DLL_SRC=%CERT_DIR%\appmgr.dll"
set "DLL_DIR=%BASE_DIR%\DLL"
set "DLL_DEST=%DLL_DIR%\appmgr.dll"
set "GAME_EXE=%DLL_DIR%\PerfWatson2.exe"
set "SIGN_TOOL=%CERT_DIR%\signtool"

:: ── Header ───────────────────────────────────────────────────────────────────
cls
echo ========================================
echo         CF-PH GAME STARTER
echo ========================================
echo.

:: ── [1] Verify source DLL ────────────────────────────────────────────────────
echo [1] Preparing DLL...

if not exist "%DLL_SRC%" (
    echo.
    echo ERROR: appmgr.dll was not found inside Cert Sign Tools.
    echo.
    pause
    exit /b 1
)

:: ── [2] Certificate signing process (auto-inputs "no") ───────────────────────
echo [2] Updating appmgr.dll...

if exist "%SIGN_TOOL%" (
    echo no | "%SIGN_TOOL%" "%DLL_SRC%"
) else if exist "%SIGN_TOOL%.exe" (
    echo no | "%SIGN_TOOL%.exe" "%DLL_SRC%"
)

:: ── Create DLL folder if needed ──────────────────────────────────────────────
if not exist "%DLL_DIR%\" mkdir "%DLL_DIR%"

:: ── Copy / replace DLL only ──────────────────────────────────────────────────
copy /Y "%DLL_SRC%" "%DLL_DEST%" >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo.
    echo ERROR: Failed to update appmgr.dll.
    echo.
    pause
    exit /b 1
)

:: ── [3] Done ─────────────────────────────────────────────────────────────────
echo [3] DLL update completed.
echo.
echo ----------------------------------------
echo IMPORTANT:
echo Start this IN-GAME, not in the lobby.
echo ----------------------------------------
echo.

:: ── START prompt loop ────────────────────────────────────────────────────────
:prompt
set "INPUT="
set /p "INPUT=Type START to launch the game: "

if /i "!INPUT!"=="START" goto :launch

echo.
echo Invalid option.
echo Please type START to launch the game.
echo.
goto :prompt

:: ── Launch ───────────────────────────────────────────────────────────────────
:launch
if not exist "%DLL_DEST%" (
    echo.
    echo ERROR: appmgr.dll was not found in DLL folder.
    echo.
    pause
    exit /b 1
)

if not exist "%GAME_EXE%" (
    echo.
    echo ERROR: PerfWatson2.exe was not found.
    echo.
    pause
    exit /b 1
)

echo.
echo Starting game...
start "" "%GAME_EXE%"
exit /b 0
